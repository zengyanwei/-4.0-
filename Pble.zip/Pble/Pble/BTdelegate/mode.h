//
//  mode.h
//  BLETools
//
//  Created by vidonn on 15/7/8.
//  Copyright (c) 2015年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface mode : NSObject
{
    NSString* rssi;
    CBPeripheral*  Peripheral;
    CBCharacteristic *chat0;
}

@property (strong,nonatomic) NSString*  rssi;
@property (strong,nonatomic) CBPeripheral*  Peripheral;
@property (strong,nonatomic) CBCharacteristic*  chat0;

@end
