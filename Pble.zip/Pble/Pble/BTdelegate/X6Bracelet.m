//
//  Bracelet.m
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-24.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#import "X6Bracelet.h"

@implementation X6Bracelet

@synthesize activePeripheral;
@synthesize name;
@synthesize pairNum;
@synthesize uuid;
@synthesize status;

@end
