//
//  mode.m
//  BLETools
//
//  Created by vidonn on 15/7/8.
//  Copyright (c) 2015年 vidonn. All rights reserved.
//

#import "mode.h"

@implementation mode

@synthesize rssi;
@synthesize Peripheral;
@synthesize chat0;

@end
