//
//  vidonn_bt_a.h
//  vidonn_bt_a
//
//  Created by 曾 言伟 on 14-1-3.
//  Copyright (c) 2014年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "X6btdelegate.h"
#import "mode.h"


typedef void (^ConnectedBlock_t)(CBPeripheral* val);
typedef void (^DisconnectedBlock_t)(BOOL val);
typedef void (^VFBLEErrorBlock_t)(NSError* error);
typedef void (^ReadDataBlock_t)(NSString *val);
typedef void (^WriteoutDataBlock_t)(NSString *val);
typedef void (^WriteDataBlock_t)(NSString *val);
typedef void (^SetNotiyfBlock_t)(BOOL val);
typedef void (^SearchBraceletBlock_t)(NSMutableArray* array);

@interface X6_bt_a : NSObject<X6btdelegate>
{
    ConnectedBlock_t ConnectedBlock;
    DisconnectedBlock_t DisconnectedBlock;
    VFBLEErrorBlock_t VFBLEErrorBlock;
    ReadDataBlock_t ReadDataBlock;
    SetNotiyfBlock_t SetNotiyfBlock;
    SearchBraceletBlock_t SearchBraceletBlock;
    WriteoutDataBlock_t WriteoutDataBlock;
    WriteDataBlock_t WriteDataBlock;
}

+(X6_bt_a *) getInstance;

-(void) SearchBracelet:(SearchBraceletBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) ConnectBraceletp:(CBPeripheral*)per blk:(ConnectedBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) DisconnectBraceletp:(CBPeripheral*)per blk:(DisconnectedBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) ReadDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart blk:(ReadDataBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) SetNotiyf:(CBPeripheral*) per chart:(CBCharacteristic*) chart blk:(SetNotiyfBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) WriteWithoutDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart value :(NSString*) value blk:(WriteoutDataBlock_t) data err:(VFBLEErrorBlock_t)err;
-(void) WriteWithDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart value :(NSString*) value blk:(WriteDataBlock_t) data err:(VFBLEErrorBlock_t)err;
@end
