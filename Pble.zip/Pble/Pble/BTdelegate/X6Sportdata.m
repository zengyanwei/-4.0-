//
//  Movementdata.m
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-26.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#import "X6Sportdata.h"

@implementation X6Sportdata

@synthesize setp;
@synthesize distance;
@synthesize calorie;
@synthesize time;
@synthesize index;
@synthesize packagetype;
@synthesize dayindex;
@synthesize sporttype;
@synthesize hourindex;
@synthesize minute;
@synthesize error;
@synthesize index2data;
@synthesize data2index;
@synthesize setpls;
@synthesize slptype;

@end
