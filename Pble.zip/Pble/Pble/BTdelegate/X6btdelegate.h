//
//  btdelegate.h
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-24.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>

@protocol X6btdelegate <NSObject>

- (void) didConnectPeripheral:(CBPeripheral*) p;
- (void) didDisConnectBracelet;
- (void) didSearchPeripheral:(NSMutableArray*) Peripherals;
- (void) didRead:(NSData*) value;
- (void) didWrite:(NSData*) value;
- (void) didNotyf:(BOOL) value;
@end
