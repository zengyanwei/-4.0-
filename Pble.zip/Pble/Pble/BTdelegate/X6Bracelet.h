//
//  Bracelet.h
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-24.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>

@interface X6Bracelet : NSObject
{
    CBPeripheral *activePeripheral;
    NSString* name;
    NSString* pairNum;
    NSString* uuid;
    NSString* status;
}

@property (nonatomic, strong) CBPeripheral  *activePeripheral;
@property (nonatomic, strong) NSString  *name;
@property (nonatomic, strong) NSString  *pairNum;
@property (nonatomic, strong) NSString  *uuid;
@property (nonatomic, strong) NSString  *status;

@end
