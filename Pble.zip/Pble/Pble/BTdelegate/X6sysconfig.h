//
//  sysconfig.h
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-24.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#ifndef vidonn_bt_dll_sysconfig_h
#define vidonn_bt_dll_sysconfig_h

#define main_service_UUID              0xFF01//计步器服务

#define device_name_UUID               0xF010//设备名
#define pair_UUID                      0xF007//配对码
#define versions_UUID                  0xF012//版本
#define personal_UUID                  0xF013//个人信息
#define movementData_UUID              0xF014//运动数据
#define macaddress_UUID                0xF015//mac地址
#define date_UUID                      0xF016//日期
#define clock_UUID                     0xF017//闹钟
#define Alarm_UUID                     0xF018//告警
#define movementData_current_UUID      0xF019//运动实时数据
#define Version_UUID                   0xF012//版本
#define Sedentary_UUID                 0xF01B//久坐
#define Sleep_UUID                     0xF01C//睡眠
#define NotDisturb_UUID                0xF01D//勿扰

#define main_battery_UUID              0x180F//电量服务
#define battery_UUID                   0x2A19//电量

#define main_service_UUID_2            0xFFE0
#define Characteristics_UUID_2         0xFFE4
#define Characteristics_AllSetp_Notify         0xFFE1

#define main_service_Notify               0xFFE5
#define Characteristics_RT_Notify         0xFFE9

#define main_DevInfo_UUID              0x180A//设备信息服务
#define DevInfo_UUID                   0x2A28//软件版本号

#define update_service_UUID         0xFFF0
#define Characteristics_OP          0xFFF1
#define Characteristics_DA          0xFFF2
#define Characteristics_DE          0xFFF3

#endif
