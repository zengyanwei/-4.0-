//
//  vidonn_bt_a.m
//  vidonn_bt_a
//
//  Created by 曾 言伟 on 14-1-3.
//  Copyright (c) 2014年 vidonn. All rights reserved.
//

#import "X6_bt_a.h"
#import "X6Bluetooth.h"
#import "X6Bracelet.h"
#import "X6sysconfig.h"
#import "X6Sportdata.h"
#import "X6BlePkt.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>


@implementation X6_bt_a
{
    X6Bluetooth *bt;
    CBPeripheral *activePeripheral;
}

+(X6_bt_a *) getInstance
{
    static dispatch_once_t pred = 0;
    static X6_bt_a *sharedInstance = nil;
    dispatch_once(&pred, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

-(id)init
{
    if (self = [super init]) {
        bt = [[X6Bluetooth alloc] init:self];
    }
    return self;
}

-(void) SearchBracelet:(SearchBraceletBlock_t) data err:(VFBLEErrorBlock_t)err
{
    SearchBraceletBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    //[bt scan];
    [self BluetoothWhitelist];
}

-(void) BluetoothWhitelist
{
    [bt scanConnectedPeripheralsWithServices];
}

- (void) didSearchPeripheral:(NSMutableArray*) Peripherals
{
    SearchBraceletBlock(Peripherals);
}

-(void) ConnectBraceletp:(CBPeripheral*)per blk:(ConnectedBlock_t) data err:(VFBLEErrorBlock_t)err
{
    ConnectedBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    [bt connectPeripheral:per];
}

-(void) DisconnectBraceletp:(CBPeripheral*)per blk:(DisconnectedBlock_t) data err:(VFBLEErrorBlock_t)err
{
    DisconnectedBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    if(per.state)
    {
        [bt disconnectPeripheral:per];
    }
}

- (void) didConnectPeripheral:(CBPeripheral*) p
{
    ConnectedBlock(p);
}

- (void) didDisConnectBracelet
{
    if(DisconnectedBlock)
        DisconnectedBlock(YES);
}

-(void) ReadDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart blk:(ReadDataBlock_t) data err:(VFBLEErrorBlock_t)err
{
    ReadDataBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    if(per.state == 2)
    {
        [bt readValuep:chart p:per];
    }
}

-(void) WriteWithoutDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart value :(NSString*) value blk:(WriteoutDataBlock_t) data err:(VFBLEErrorBlock_t)err
{
    WriteoutDataBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    if(per.state == 2)
    {
        NSString* str;
        NSString *val = [value stringByTrimmingCharactersInSet:
                         [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        UInt8 *xval = (UInt8*)malloc(val.length/2);
        for(int i = 0 ,j = 0; i < val.length;i=i+2,j++)
        {
            NSRange monthRang = NSMakeRange(i, 2);
            str = [val substringWithRange:monthRang];
            xval[j] = [self stringFromHexString:str];
        }
        NSData *d = [[NSData alloc] initWithBytes:xval length:val.length/2];
        [bt WriteWithoutValuep:chart p:per value:d];
    }
}

-(void) WriteWithDataBlock:(CBPeripheral*) per chart:(CBCharacteristic*) chart value :(NSString*) value blk:(WriteDataBlock_t) data err:(VFBLEErrorBlock_t)err
{
    WriteDataBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    if(per.state == 2)
    {
        NSString* str;
        NSString *val = [value stringByTrimmingCharactersInSet:
                         [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        UInt8 *xval = (UInt8*)malloc(val.length/2);
        for(int i = 0 ,j = 0; i < val.length;i=i+2,j++)
        {
            NSRange monthRang = NSMakeRange(i, 2);
            str = [val substringWithRange:monthRang];
            xval[j] = [self stringFromHexString:str];
        }
        NSData *d = [[NSData alloc] initWithBytes:xval length:val.length/2];
        [bt WriteWithValuep:chart p:per value:d];
    }
}

- (int)stringFromHexString:(NSString *)hexString { //
    
    unsigned int anInt;
    NSScanner * scanner = [[NSScanner alloc] initWithString:hexString];
    [scanner scanHexInt:&anInt];
    return anInt;
}

-(void) SetNotiyf:(CBPeripheral*) per chart:(CBCharacteristic*) chart blk:(SetNotiyfBlock_t) data err:(VFBLEErrorBlock_t)err
{
    SetNotiyfBlock = [data copy];
    VFBLEErrorBlock = [err copy];
    [bt setnotiyf:chart p:per];
}

- (void) didNotyf:(BOOL) value
{
    if(SetNotiyfBlock)
    SetNotiyfBlock(value);
}

- (void) didRead:(NSData*) value
{
    UInt8 *xval = (UInt8*)malloc(value.length);
    [value getBytes:xval length:value.length];
    NSMutableString *str = [[NSMutableString alloc] init];
    for(int i = 0; i < value.length; i++)
    {
        [str appendFormat:@"%02x ",xval[i]];
    }
    if(ReadDataBlock)
    ReadDataBlock(str);
}

- (void) didWrite:(NSData*) value
{
    UInt8 *xval = (UInt8*)malloc(value.length);
    [value getBytes:xval length:value.length];
    NSMutableString *str = [[NSMutableString alloc] init];
    for(int i = 0; i < value.length; i++)
    {
        [str appendFormat:@"%02x ",xval[i]];
    }
    if(WriteDataBlock)
    WriteDataBlock(str);
}

@end
