//
//  Biuetooth.h
//  vidonn_bt_dll
//
//  Created by 曾 言伟 on 13-12-24.
//  Copyright (c) 2013年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>
#import "X6btdelegate.h"


#if DEBUG
#warning NSLogs will be shown
#else
#define NSLog(...) {}
#endif

@interface X6Bluetooth : NSObject<CBCentralManagerDelegate, CBPeripheralDelegate>
{
    NSMutableArray *bracelets;
    CBCentralManager *CM;
    CBPeripheral *activePeripheral;
}

@property (nonatomic, assign) id<X6btdelegate>  Bdelegate;

@property (strong, nonatomic) NSMutableArray *bracelets;
@property (strong, nonatomic) CBCentralManager *CM;
@property (strong, nonatomic) CBPeripheral *activePeripheral;

- (id) init:(id) delegate;
- (void) scan;
- (void) stopScan;
- (void) disconnectPeripheral:(CBPeripheral *)peripheral;
- (void) connectPeripheral:(CBPeripheral *)peripheral;
-(void) readValuep:(CBCharacteristic *)chart p:(CBPeripheral*) p;
-(void) WriteWithoutValuep:(CBCharacteristic *)chart p:(CBPeripheral*) p value:(NSData*) value;
-(void) WriteWithValuep:(CBCharacteristic *)chart p:(CBPeripheral*) p value:(NSData*) value;
-(BOOL) isconnectPeripheral;
-(void) setnotiyf:(CBCharacteristic *)chart p:(CBPeripheral*) p;
-(void)scanConnectedPeripheralsWithServices;
@end
