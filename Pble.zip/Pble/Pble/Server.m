//
//  Server.m
//  Pble
//
//  Created by 曾 言伟 on 15/10/4.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import "Server.h"

@interface Server ()
@property (weak, nonatomic) IBOutlet UITextField *writevalue;
@property (weak, nonatomic) IBOutlet UILabel *wback;
@property (weak, nonatomic) IBOutlet UILabel *show;

@end

@implementation Server
@synthesize md;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.show.text = [NSString stringWithFormat:@"%@:%@",[NSString stringWithFormat:@"%@ %s",md.chat0.UUID,[self CBUUIDToString:md.chat0.UUID]],[self getProperties:md.chat0.properties]];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.writevalue resignFirstResponder];
    return YES;
}

-(const char *) CBUUIDToString:(CBUUID *) UUID {
    return [[UUID.data description] cStringUsingEncoding:NSStringEncodingConversionAllowLossy];
}

-(NSString*) getProperties:(CBCharacteristicProperties) pro
{
    NSMutableString* spro = [[NSMutableString alloc] init];
    
    if((pro & 0x200) == 0x200)
        [spro appendString:@"IndicateEncryptionRequired"];
    if((pro & 0x100) == 0x100)
        [spro appendString:@"NotifyEncryptionRequired  "];
    if((pro & 0x80) == 0x80)
        [spro appendString:@"ExtendedProperties  "];
    if((pro & 0x40) == 0x40)
        [spro appendString:@"AuthenticatedSignedWrites  "];
    if((pro & 0x20) == 0x20)
        [spro appendString:@"Indicate  "];
    if((pro & 0x10) == 0x10)
        [spro appendString:@"Notify  "];
    if((pro & 0x08) == 0x08)
        [spro appendString:@"Write  "];
    if((pro & 0x04) == 0x04)
        [spro appendString:@"WriteWithoutResponse  "];
    if((pro & 0x02) == 0x02)
        [spro appendString:@"Read  "];
    if((pro & 0x01) == 0x01)
        [spro appendString:@"Broadcast"];
    return spro;
}

- (IBAction)write:(UIButton *)sender {
    if(self.writevalue.text.length <= 0 || self.writevalue.text.length % 2 != 0){
        UIAlertView *alter
             = [[UIAlertView alloc] initWithTitle:@"" message:NSLocalizedString(@"输入数据格式不对", nil) delegate:self cancelButtonTitle:NSLocalizedString(@"确定", nil) otherButtonTitles:nil];
        [alter show];
        return;
    }
    if((md.chat0.properties & 0x04) == 0x04)//WriteWithoutResponse
    {
        [[X6_bt_a getInstance] WriteWithoutDataBlock:md.Peripheral chart:md.chat0 value:self.writevalue.text  blk:^(NSString* val){
            
        }err:^(NSError* error){
            
        }];
    }
    else if((md.chat0.properties & 0x08) == 0x08)//Write
    {
        self.wback.hidden = NO;
        [[X6_bt_a getInstance] WriteWithDataBlock:md.Peripheral chart:md.chat0 value:self.writevalue.text  blk:^(NSString* val){
            self.wback.text = [NSString stringWithFormat:@"写返回值:%@",val];
        }err:^(NSError* error){
            
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
