//
//  ViewController.m
//  Pble
//
//  Created by 曾 言伟 on 15/10/4.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import "ViewController.h"
#import "X6_bt_a.h"

@interface ViewController ()
{
    NSMutableArray* LSections;
    NSArray* LSectionssort;
    mode *clk;
}
@property (weak, nonatomic) IBOutlet UITableView *perlist;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [X6_bt_a getInstance];
    LSections = [NSMutableArray array];
    LSectionssort = [NSArray array];
}

- (IBAction)searchBtn:(UIButton *)sender {
    if(clk.Peripheral != nil){
       [[X6_bt_a getInstance] DisconnectBraceletp:clk.Peripheral blk:^(BOOL val){
           
       }err:^(NSError* error){
        
       }];
        sleep(2);
    }
    [LSections removeAllObjects];
    [[X6_bt_a getInstance] SearchBracelet:^(NSMutableArray* array) {
        LSections = array;
        //  NSLog(@"%@" ,LSections);
        LSectionssort = [self sortData];
        [self.perlist reloadData];
    }err:^(NSError *error){
        
    }];
}

-(NSArray*) sortData
{
    NSComparator cmptr = ^(id obj1, id obj2){
        int i1 = [((mode*)obj1).rssi intValue];
        int i2 = [((mode*)obj2).rssi intValue];
        if (i2 > i1) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        
        if (i2 < i1) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    };
    return [LSections sortedArrayUsingComparator:cmptr];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [LSectionssort count];
}

- (CGFloat)tableView:(UITableView *)atableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   // if(tableView == self.searchTablev)
    {
        static NSString *CellIdentifier = @"Celll";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
        }
        cell.textLabel.text = ((mode*)[LSectionssort objectAtIndex:indexPath.row]).Peripheral.name;
        [cell.detailTextLabel setNumberOfLines:4];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@\n信号:%@",((mode*)[LSectionssort objectAtIndex:indexPath.row]).Peripheral.identifier.UUIDString,((mode*)[LSectionssort objectAtIndex:indexPath.row]).rssi];
        
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self performSegueWithIdentifier:@"link" sender:indexPath];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    UIViewController *destination = segue.destinationViewController;
    NSIndexPath *index = (NSIndexPath*)sender;
    clk = (mode*)[LSectionssort objectAtIndex:index.row];
    [destination setValue:clk forKey:@"md"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
