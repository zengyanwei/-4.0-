//
//  Server.h
//  Pble
//
//  Created by 曾 言伟 on 15/10/4.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "X6_bt_a.h"

@interface Server : UIViewController<UITextFieldDelegate>
{
    __weak mode *md;
}

@property (weak,nonatomic) mode *md;
@end
